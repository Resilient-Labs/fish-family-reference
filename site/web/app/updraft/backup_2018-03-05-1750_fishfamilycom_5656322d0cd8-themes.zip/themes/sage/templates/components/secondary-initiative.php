<div class="secondary-initiative">
    <?php if (get_field('secondary_image')) : ?>
        <img src="<?php the_field('secondary_image'); ?>" />
    <?php endif; ?>
</div>